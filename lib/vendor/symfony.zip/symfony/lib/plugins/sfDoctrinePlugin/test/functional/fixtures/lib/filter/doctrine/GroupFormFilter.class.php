<?php

/**
 * Group filter form.
 *
 * @package    filters
 * @subpackage Group *
 * @version    SVN: $Id: GroupFormFilter.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class GroupFormFilter extends BaseGroupFormFilter
{
  public function configure()
  {
  }
}