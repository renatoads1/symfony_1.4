<?php

/**
 * Article filter form.
 *
 * @package    filters
 * @subpackage Article *
 * @version    SVN: $Id: ArticleFormFilter.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class ArticleFormFilter extends BaseArticleFormFilter
{
  public function configure()
  {
  }
}