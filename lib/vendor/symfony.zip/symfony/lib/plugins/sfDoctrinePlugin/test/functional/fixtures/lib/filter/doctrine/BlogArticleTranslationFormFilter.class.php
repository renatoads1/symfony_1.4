<?php

/**
 * BlogArticleTranslation filter form.
 *
 * @package    symfony12
 * @subpackage filter
 * @author     Your name here
 * @version    SVN: $Id: BlogArticleTranslationFormFilter.class.php 23668 2009-11-07 12:51:07Z Kris.Wallsmith $
 */
class BlogArticleTranslationFormFilter extends BaseBlogArticleTranslationFormFilter
{
  public function configure()
  {
  }
}
